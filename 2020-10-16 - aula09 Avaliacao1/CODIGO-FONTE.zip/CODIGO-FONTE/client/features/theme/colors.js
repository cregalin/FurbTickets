const white = "#FFF9FB";
const darkPurple = "#2A1F2D";
const electricPurple = "#B14AED";
const xanadu = "#687873";

export { white, darkPurple, electricPurple, xanadu };
