export default [{
  title: 'Teste 1',
  description: 'lorema sapioduh asiuh enua sdpaihj eap asuiodh eiu ads jashdkaj ',
  price: 'R$10,00',
  group: 'SADdane',
  date: '23/12/1231',
  hour: '23:00'
}]
