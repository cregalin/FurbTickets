class Session {
  constructor(date, time) {
    this.date = date;
    this.time = time;
  }
}
