import styled from "styled-components/native";

export const ButtonContainer = styled.TouchableOpacity`
  width: 30px;
  height: 30px;
  justify-content: center;
  align-items: center;
`;
