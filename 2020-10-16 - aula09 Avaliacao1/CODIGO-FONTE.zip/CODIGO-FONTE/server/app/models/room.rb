class Room < ApplicationRecord
	extend Enumerize

  enumerize :role, in: [:user, :admin], default: :user
  validates :description, :type, presence: true
end
